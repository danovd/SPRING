package project.service;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import project.model.entity.Hero;
import project.model.entity.User;
import project.model.service.HeroServiceModel;
import project.repository.HeroRepository;
import project.util.CurrentUser;

import java.util.List;
import java.util.Set;

@Service
public class HeroServiceImpl implements HeroService {
    private final HeroRepository heroRepository;
    private final ModelMapper modelMapper;
    private final UserService userService;
    private final CurrentUser currentUser;

    public HeroServiceImpl(HeroRepository heroRepository, ModelMapper modelMapper, UserService userService, CurrentUser currentUser) {
        this.heroRepository = heroRepository;
        this.modelMapper = modelMapper;
        this.userService = userService;
        this.currentUser = currentUser;
    }

    @Override
    public void create(HeroServiceModel heroServiceModel) {
        Hero hero = modelMapper.map(heroServiceModel, Hero.class);
        User creator = userService.findById(currentUser.getId());
        hero.setUser(creator);

        heroRepository.save(hero);
    }

    @Override
    public List<Hero> getAllHeroes() {
        return heroRepository.findAll();
    }

    @Override
    public Hero getHeroById(String id) {
        return heroRepository.findById(id).orElse(null);
    }

    @Override
    public void deleteHeroById(String id) {
        heroRepository.deleteById(id);
    }
}
