package project.service;

import project.model.entity.Hero;
import project.model.service.HeroServiceModel;

import java.util.List;
import java.util.Set;

public interface HeroService {
    void create(HeroServiceModel map);

    List<Hero> getAllHeroes();

    Hero getHeroById(String id);

    void deleteHeroById(String id);
}
