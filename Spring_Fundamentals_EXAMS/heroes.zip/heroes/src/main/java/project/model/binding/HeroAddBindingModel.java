package project.model.binding;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import project.model.entity.ClazzName;

public class HeroAddBindingModel {


    private String name;
    private ClazzName clazzName;
    private Integer level;


    public HeroAddBindingModel() {
    }

    @NotBlank
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    @NotNull
    public ClazzName getClazzName() {
        return clazzName;
    }
    public void setClazzName(ClazzName clazzName) {
        this.clazzName = clazzName;
    }

    @NotNull
    @Positive
    public Integer getLevel() {
        return level;
    }
    public void setLevel(Integer level) {
        this.level = level;
    }
}
