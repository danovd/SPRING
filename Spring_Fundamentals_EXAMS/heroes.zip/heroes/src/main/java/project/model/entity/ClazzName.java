package project.model.entity;

public enum ClazzName {
    WARRIOR, ARCHER, MAGE
}
