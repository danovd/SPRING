package project.model.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "heros")
public class Hero extends BaseEntity{

    private String name;
    private ClazzName clazzName;
    private Integer level;
    private User user;


    public Hero() {
    }

    @Column(nullable = false, unique = true)
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }


    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    public ClazzName getClazzName() {
        return clazzName;
    }
    public void setClazzName(ClazzName clazzName) {
        this.clazzName = clazzName;
    }


    @Column(nullable = false)
    public Integer getLevel() {
        return level;
    }
    public void setLevel(Integer level) {
        this.level = level;
    }

    @ManyToOne
    @JoinColumn(nullable = false)
    public User getUser() {
        return user;
    }
    public void setUser(User user) {
        this.user = user;
    }
}
