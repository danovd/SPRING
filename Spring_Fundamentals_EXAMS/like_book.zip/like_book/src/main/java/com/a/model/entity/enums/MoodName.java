package com.a.model.entity.enums;

public enum MoodName {
    HAPPY, SAD, INSPIRED
}
